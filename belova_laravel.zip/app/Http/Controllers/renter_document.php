<?php

namespace App\Http\Controllers;

use App\Models\renter_document;
use Illuminate\Http\Request;

class renter_document extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(renter_document $renter_document)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(renter_document $renter_document)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, renter_document $renter_document)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(renter_document $renter_document)
    {
        //
    }
}
