<footer class="footer text-center text-sm-left">
    &copy; {{date('Y')}} belova.id <span class="d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger">

        </i> by <a href="http://alphaproject.rf.gd/#about-me" target="_blank">Alpha Studio</a></span>
</footer>